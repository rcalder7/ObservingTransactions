//Ricardo Calderon
//Project 5, Observer 
//Due Date 3/15/2019
//Submitted 3/14/2019


package project5Calderon;

import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Observable;
import java.util.Observer;
public class TransactionLogger implements Observer{
    PrintWriter _log;
    
    public TransactionLogger(String fileName) 
        throws FileNotFoundException {
        _log = new PrintWriter(fileName);
    }
//prints to the log
	@Override
	public void update(Observable obs, Object info) {
		_log.println(info);
		_log.flush( );
		
		//System.out.println("Student Name: " + info);
		//System.out.println("Message board changed.");
		//System.out.println("New message: " + info);
		//System.out.println( );
		
		
	}
}