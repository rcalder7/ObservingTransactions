//Ricardo Calderon
//Project 5, Observer 
//Due Date 3/15/2019
//Submitted 3/14/2019
//Ricardo Calderon
//Project 5, Observer 
//Due Date 3/15/2019
//Submitted 3/14/2019
package project5Calderon;

//Source Code Cile: TransactionChecker.java
//For Project 5S.
//To be modified.

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Observable;
import java.util.Scanner;
public class TransactionChecker extends Observable {
 Scanner _in;
 
 public TransactionChecker(String fileName) 
     throws FileNotFoundException {
     _in = new Scanner(new File(fileName));
 }
 // the transaction tracker adds new obkects and checks for a Eugene  and amount of 50000 and above.
 public void checkTransactions( ) {
	 int idStart= 1001;
     while(_in.hasNextLine( )) {
         String line = _in.nextLine( );
         String[ ] fields = line.split(",");
         String buyer = fields[0];
         String seller = fields[1];
         double theAmt = Double.parseDouble(fields[2]);
         String timestamp = fields[3];
        
        
         Transaction trans = new Transaction(idStart, seller, buyer, theAmt,"blank memo" , timestamp);
         //System.out.println(trans);
         
         if (trans.getBuyer().equals("Eugene Eko") && trans.getAmount() >  50000) {
        	 setChanged( );
        	 notifyObservers(trans);
        	 //System.out.println("hello");
     	 
         }
        // System.out.println(trans);
     	idStart++;
     	
         
         
     }
     _in.close( );
 }

}