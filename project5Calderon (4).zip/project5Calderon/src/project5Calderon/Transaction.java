//Ricardo Calderon
//Project 5, Observer 
//Due Date 3/15/2019
//Submitted 3/14/2019

package project5Calderon;



public class Transaction  {
	// instance variables being made for transactions
	private int _id;
	private String _buyer;
	private String _seller;
	private double _amount;
	private String _memo;
	private String _timestamp; 
	
	// the constructor for transactions
	public Transaction(int theId, String theSeller, String theBuyer, double theAmt, String theMemo,String theTs ) {
		_id = theId;
		_buyer = theBuyer;
		_seller=  theSeller;
		_amount = theAmt;
		_memo = theMemo;
		_timestamp = theTs;
		
	}
// getters and setter for all instance variables
	public int get_id() {
		return _id;
	}

	public String getBuyer() {
		return _buyer;
	}

	public String getSeller() {
		return _seller;
	}

	public double getAmount() {
		return _amount;
	}

	public String get_memo() {
		return _memo;
	}

	public String get_timestamp() {
		return _timestamp;
	}

	@Override
	public String toString() {
		return "Transaction [_id=" + _id + ", _buyer=" + _buyer + ", _seller=" + _seller + ", _amount=" + _amount
				+ ", _memo=" + _memo + ", _timestamp=" + _timestamp + "]";
		
	} 
	


}