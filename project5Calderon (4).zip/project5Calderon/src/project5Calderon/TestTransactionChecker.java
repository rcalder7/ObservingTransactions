
//Ricardo Calderon
//Project 5, Observer 
//Due Date 3/15/2019
//Submitted 3/14/2019
package project5Calderon;

import java.io.FileNotFoundException;
// tested methods and observer
public class TestTransactionChecker {

	public static void main(String[] args) throws FileNotFoundException {
	TransactionChecker transChk = new TransactionChecker("transactions.txt");
	TransactionLogger transLog = new TransactionLogger("log.txt");
	transChk.addObserver(transLog);
	transChk.checkTransactions();
	

	}

}
